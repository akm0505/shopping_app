﻿using BAL.BEEntities;
using BAL.Classes;
using BAL.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;

namespace eCartAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class eCartController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public readonly IECart _eCartService;

        public eCartController(IConfiguration configuration, IECart eCartService)
        {
            _eCartService = eCartService;
            _configuration = configuration;
        }

        [HttpGet]
        [Route("GetCategoryList/{type?}")]
        public IActionResult GetCategoryList(string type = "")
        {
            var items = _eCartService.GetCategoryList(type);
            if(items != null)
            {
                return Ok(items);
            }
            return BadRequest();

        }

        [HttpPost]
        [Route("GetUserLoginDetail")]
        public IActionResult GetUserLoginDetail(UserCredential oUser)
        {
            if (oUser != null)
            {
                if (!String.IsNullOrEmpty(oUser.USER_PHONE) && !String.IsNullOrEmpty(oUser.USER_PASSWORD))
                {
                    if (Validate(oUser))
                    {
                        var items = _eCartService.GetUserDetail(oUser.USER_PHONE);
                        if (items != null)
                        {
                            return Ok(items);
                        }
                        else
                        {
                            return BadRequest("You are not authorized to access this application.");
                        }
                    }
                    else
                    {
                        return BadRequest("You are not authorized to access this application.");
                    }
                }
                else
                {
                    return BadRequest("Please enter valid credential.");
                }
            }
            return BadRequest();

        }


        private bool Validate(UserCredential oUser)
        {
            return _eCartService.Validate(oUser);
        }

        [HttpGet]
        [Route("GetUserDetail/{mobileNumber}")]
        public IActionResult GetUserDetail(string mobileNumber)
        {
            var items = _eCartService.GetUserDetail(mobileNumber);
            if (items != null)
            {
                return Ok(items);
            }
            return BadRequest();

        }

    }
}
