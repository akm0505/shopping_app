﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.BEEntities
{
    public class eCart
    {
    }

    public class CategoryList
    {
        public List<CategoryDetail>? CategoryDetails { get; set; }
    }

    public class CategoryDetail
    {
        public long CATEGORY_ID { get; set; }
        public string? CATEGORY_NAME { get; set; }
        public string? IMAGE_URL { get; set; }
    }

    public class UserDetail
    {
        public long USER_ID { get; set; }
        public string? USER_NAME { get; set; }
        public string? USER_DISPLAY_NAME { get; set; }
        public string? USER_EMAIL { get; set; }
        public string? USER_PHONE { get; set; }
        public string? USER_PASSWORD { get; set; }
        public string? USER_PHONE2 { get; set; }
        public string? USER_ADDRESS { get; set; }
        public string? USER_ADDRESS_1 { get; set; }
        public string? USER_CITY { get; set; }
        public string? USER_STATE { get; set; }
        public string? USER_COUNTRY { get; set; }
        public string? USER_PINCODE { get; set; }
        public string? USER_PROFILE_PIC    { get; set; }
        
    }

    public class CMessage
    {
        public string? RESPONSE_TYPE { get; set; }
        public string? RESPONSE_MESSAGE { get; set; }
    }

    public class UserCredential
    {
        public string? USER_PHONE { get; set; }  
        public string? USER_PASSWORD { get; set; }   
        public string? OAUTH_TOKEN { get; set; }
    }
}
