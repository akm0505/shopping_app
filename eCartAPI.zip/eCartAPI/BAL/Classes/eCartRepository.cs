﻿using BAL.BEEntities;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Repositories
{
    public class eCartRepository
    {
        private readonly IConfiguration _configuration;
        //var connString = configuration.GetConnectionString("ProductsDb");
        //public readonly IC
        //public static string ConnString = "Server=sql.bsite.net\\MSSQL2016;Database=akm0505_mahakal;User Id=akm0505_mahakal;Password=Abhishek@123;";

        public eCartRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string? GetDBConnectionString()
        {
            return _configuration.GetConnectionString("ProdConnectionString");
        }
        

       
        public CategoryList GetCategoryList(string type = "")
        {
            var cList = new CategoryList();
            SqlDataReader reader ;
            SqlConnection sqlConnection = new SqlConnection(GetDBConnectionString());
            List<CategoryDetail> cDetail = new List<CategoryDetail>();

            try
            {
                using (sqlConnection)
                {
                    string strCommandText = "ECART_CategoryDetails_GET";

                    using (SqlCommand cmd = new SqlCommand(strCommandText, sqlConnection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@type", type);
                        sqlConnection.Open();

                        using (reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                CategoryDetail cItem = new CategoryDetail();
                                cItem.CATEGORY_ID = Convert.ToInt64(reader["CATEGORY_ID"]);
                                cItem.CATEGORY_NAME = Convert.ToString(reader["CATEGORY_NAME"]);
                                cItem.IMAGE_URL = Convert.ToString(reader["IMAGE_URL"]);
                                cDetail.Add(cItem);
                            }
                        }
                    }



                }
                cList.CategoryDetails = cDetail;
                return cList;
            }catch(Exception ex)
            {
                throw;
            }

        }


        public UserDetail GetUserDetail(string mobileNumber)
        {
            var cUser = new UserDetail();
            SqlDataReader reader;
            SqlConnection sqlConnection = new SqlConnection(GetDBConnectionString());

            try
            {
                using (sqlConnection)
                {
                    string strCommandText = "ECART_UserDetail_GET";

                    using (SqlCommand cmd = new SqlCommand(strCommandText, sqlConnection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@mobileNumber", mobileNumber);
                        sqlConnection.Open();

                        using (reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                cUser.USER_NAME = Convert.ToString(reader["USER_NAME"]);
                                cUser.USER_DISPLAY_NAME = Convert.ToString(reader["USER_DISPLAY_NAME"]);
                                cUser.USER_ADDRESS = Convert.ToString(reader["USER_ADDRESS"]);
                                cUser.USER_PHONE = Convert.ToString(reader["USER_PHONE"]);
                            }
                        }
                    }
                }
                return cUser;
            }
            catch (Exception ex)
            {
                throw;
            }

        }

        public bool Validate(UserCredential oUser)
        {
            SqlDataReader reader;
            SqlConnection sqlConnection = new SqlConnection(GetDBConnectionString());

            try
            {
                using (sqlConnection)
                {
                    string strCommandText = "ECART_User_Validate";

                    using (SqlCommand cmd = new SqlCommand(strCommandText, sqlConnection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@mobileNumber", oUser.USER_PHONE);
                        cmd.Parameters.AddWithValue("@Password", oUser.USER_PASSWORD);
                        sqlConnection.Open();

                        using (reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                if(Convert.ToInt32(reader["IS_VALID_USER"]).Equals(1))
                                {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return false;
        }

    }
}
