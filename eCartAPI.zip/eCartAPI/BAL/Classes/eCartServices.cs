﻿using BAL.BEEntities;
using BAL.Interfaces;
using DAL.Repositories;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;


namespace BAL.Classes
{
    public class eCartServices : IECart
    {
        private readonly IConfiguration _configuration;
        public eCartServices(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public CategoryList GetCategoryList(string type = "")
        {
            eCartRepository oRepo = new eCartRepository(_configuration);
            var items = oRepo.GetCategoryList(type);

            if (items != null)
            {
                return items;
                //return Mapper.Map<CategoryList>(items);
            }
            return null;
        }

        public UserDetail GetUserDetail(string mobileNumber)
        {
            eCartRepository oRepo = new eCartRepository(_configuration);
            var items = oRepo.GetUserDetail(mobileNumber);

            if (items != null)
            {
                return items;
                //return Mapper.Map<CategoryList>(items);
            }
            return null;
        }

        public bool Validate(UserCredential oUser)
        {
            eCartRepository oRepo = new eCartRepository(_configuration);
            return oRepo.Validate(oUser);
        }
    }
}
