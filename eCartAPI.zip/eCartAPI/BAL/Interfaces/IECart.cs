﻿using BAL.BEEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.Interfaces
{
    public interface IECart
    {
        CategoryList GetCategoryList(string type = "");
        UserDetail GetUserDetail(string mobileNumber);
        bool Validate(UserCredential oUser);

    }
}
