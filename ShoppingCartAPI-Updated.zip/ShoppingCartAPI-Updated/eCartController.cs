﻿using BAL.BEEntities;
using BAL.Classes;
using BAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using DataAccessHandler;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;
using DAL.Repositories;
using Swashbuckle.Swagger;

namespace ShoppingCartAPI2.WebAPIs
{

    [Route("api/[controller]")]
    public class eCartController : ApiController
    {
        public readonly IECart _eCartService;

        public eCartController()
        {
            //eCartRepository _eCartService = new eCartRepository();
            _eCartService = new eCartServices();
        }
        //public eCartController(IConfiguration configuration, IECart eCartService)
        //{
        //    _eCartService = eCartService;
        //    //_configuration = configuration;
        //}

        [HttpGet]
        [Route("api/GetCategoryList/{shopId}")]
        public HttpResponseMessage GetCategoryList(long shopId)
        {
            //eCartServices temp = new eCartServices();
            eCartRepository _eCartService = new eCartRepository();

            var items = _eCartService.GetCategoryList(shopId);
            var response = Request.CreateResponse(HttpStatusCode.OK);

            if (items != null)
            {
                string jsonString = string.Empty;
                jsonString = JsonConvert.SerializeObject(items, Formatting.Indented);
                //return Ok(jsonString);
                response.Content = new StringContent(jsonString, Encoding.UTF8, "application/json");
            }
            else
                response = Request.CreateResponse(HttpStatusCode.BadRequest);

            return response;
            //return BadRequest();

        }

        [HttpPost]
        [Route("api/GetCustomerLoginDetail")]
        public HttpResponseMessage GetCustomerLoginDetail(CustomerCredential oCustomer)
        {
            var response = Request.CreateResponse(HttpStatusCode.OK);
            eCartRepository _eCartService = new eCartRepository();

            if (oCustomer != null)
            {
                if (!String.IsNullOrEmpty(oCustomer.CUSTOMER_LOGIN_ID) && !String.IsNullOrEmpty(oCustomer.CUSTOMER_PASSWORD))
                {
                    if (Validate(oCustomer))
                    {
                        var items = _eCartService.GetCustomerDetail(oCustomer.CUSTOMER_LOGIN_ID,oCustomer.SHOP_ID,oCustomer.CUSTOMER_ROLE_ID);
                        if (items != null)
                        {
                            string jsonString = string.Empty;
                            jsonString = JsonConvert.SerializeObject(items, Formatting.Indented);
                            //return Ok(jsonString);
                            response.Content = new StringContent(jsonString, Encoding.UTF8, "application/json");
                            //return Ok(items);
                        }
                        else
                        {
                            //return BadRequest("You are not authorized to access this application.");
                            response = Request.CreateResponse(HttpStatusCode.BadRequest);
                        }
                    }
                    else
                    {
                        //return BadRequest("You are not authorized to access this application.");
                        response = Request.CreateResponse(HttpStatusCode.BadRequest);

                    }
                }
                else
                {
                    //return BadRequest("Please enter valid credential.");
                    response = Request.CreateResponse(HttpStatusCode.BadRequest);
                }
            }
            //return BadRequest();
            return response;

        }


        [HttpPost]
        [Route("api/CustomerRegisteration")]
        public HttpResponseMessage CustomerRegisteration(CustomerDetail oCustomer)
        {
            //var response = Request.CreateResponse(HttpStatusCode.OK);
            eCartRepository _eCartService = new eCartRepository();

            if (oCustomer != null)
            {
                if (!String.IsNullOrEmpty(oCustomer.CUSTOMER_PHONE) && !String.IsNullOrEmpty(oCustomer.CUSTOMER_PASSWORD))
                {
                    var oResponse = _eCartService.CustomerRegisteration(oCustomer);
                    return Request.CreateResponse(HttpStatusCode.OK,oResponse);
                    //return Ok(oResponse);
                    //response.Content = new StringContent(oResponse, Encoding.UTF8, "application/json");
                }
                else
                {
                    //return BadRequest("Please enter valid credential.");
                    return Request.CreateResponse(HttpStatusCode.BadRequest, "Please enter valid credential.");

                }
            }
            //return BadRequest();
            return Request.CreateResponse(HttpStatusCode.BadRequest, "Please enter valid credential.");

        }


        private bool Validate(CustomerCredential oCustomer)
        {
            return _eCartService.Validate(oCustomer);
        }

        [HttpGet]
        [Route("api/GetCustomerDetail/{customerLoginId}/{shopId}/{CustomerRoleId}")]
        public HttpResponseMessage GetCustomerDetail(string customerLoginId,long shopId, int CustomerRoleId)
        {
            eCartRepository _eCartService = new eCartRepository();
            var items = _eCartService.GetCustomerDetail(customerLoginId, shopId, CustomerRoleId);
            var response = Request.CreateResponse(HttpStatusCode.OK);

            if (items != null)
            {
                string jsonString = string.Empty;
                jsonString = JsonConvert.SerializeObject(items, Formatting.Indented);
                response.Content = new StringContent(jsonString, Encoding.UTF8, "application/json");
                //return Ok(jsonString);
                //return Ok(items);
            }
            else
                response = Request.CreateResponse(HttpStatusCode.BadRequest);

            //return BadRequest();
            return response;

        }

        [HttpGet]
        [Route("api/GetInitialSetup/{shopId}")]
        public HttpResponseMessage GetInitialSetup(long shopId)
        {
            eCartRepository _eCartService = new eCartRepository();
            var items = _eCartService.GetInitialSetup(shopId);
            var response = Request.CreateResponse(HttpStatusCode.OK);

            if (items != null)
            {
                string jsonString = string.Empty;
                jsonString = JsonConvert.SerializeObject(items, Formatting.Indented);
                //return Ok(jsonString);
                response.Content = new StringContent(jsonString, Encoding.UTF8, "application/json");
            }
            else
                response = Request.CreateResponse(HttpStatusCode.BadRequest);

            //return BadRequest();
            return response;

        }

        [HttpGet]
        [Route("api/GetProductList/{categoryId}")]
        public HttpResponseMessage GetProductList(long categoryId)
        {
            eCartRepository _eCartService = new eCartRepository();
            var items = _eCartService.GetProductList(categoryId);
            var response = Request.CreateResponse(HttpStatusCode.OK);

            if (items != null)
            {
                string jsonString = string.Empty;
                jsonString = JsonConvert.SerializeObject(items, Formatting.Indented);
                //return Ok(jsonString);
                response.Content = new StringContent(jsonString, Encoding.UTF8, "application/json");
            }
            else
                response = Request.CreateResponse(HttpStatusCode.BadRequest);

            //return BadRequest();
            return response;

        }


        [HttpGet]
        [Route("api/GetProductDetail/{productId}/{customerId}")]
        public HttpResponseMessage GetProductDetail(long productId, long customerId)
        {
            eCartRepository _eCartService = new eCartRepository();
            var items = _eCartService.GetProductDetail(productId, customerId);
            var response = Request.CreateResponse(HttpStatusCode.OK);

            if (items != null)
            {
                string jsonString = string.Empty;

                if (items.Tables[0].Rows.Count  > 0)
                {
                    jsonString = JsonConvert.SerializeObject(items, Formatting.Indented);
                }
                response.Content = new StringContent(jsonString, Encoding.UTF8, "application/json");
                
                //return Ok(jsonString);
            } else
                response = Request.CreateResponse(HttpStatusCode.BadRequest);
            //return BadRequest();
            return response;

        }

    }
}
